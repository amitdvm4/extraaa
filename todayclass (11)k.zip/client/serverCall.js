function sendReq(method, url, data, scb, ecb) {
    var httpObj = new XMLHttpRequest();
    httpObj.open(method, url, true);
    if (data) {
        httpObj.setRequestHeader('Content-Type', 'application/json');
        httpObj.send(JSON.stringify(data));
    } else {
        httpObj.send()
    }

    httpObj.onload=function(){
        debugger;
        scb(httpObj.responseText);
    }

    httpObj.onerror=function(){
        debugger;
        ecb('something went wrong');
    }
}