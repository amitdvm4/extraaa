function fnReg() {
    //take ref
    var loaderRef=document.querySelector('#loader');
    var nameRef = document.querySelector('p:nth-child(2) > input');
    var rnoRef = document.querySelector('p:nth-child(3) > input');
    var phoneRef = document.querySelector('p:nth-child(4) > input');
    var emailRef = document.querySelector('p:nth-child(5) > input');
    var msgRef = document.querySelector('#msg');
    var btnRef=document.querySelector('[type=button]');
    var btnRef=document.querySelector('[type=button]');
    btnRef.setAttribute('disabled','disabled');
    loaderRef.classList.remove('disp-none');
    //tave values

    var n = nameRef.value;
    var r = rnoRef.value;
    var p = phoneRef.value;
    var e = emailRef.value;

    if (n == '' || r == '' || p == '' || e == '') {
        alert('please enter valid data');
        return;
    }

    var dataObj = {
        "name": n,
        "rno": r,
        "phone": p,
        "email": e
    }


    sendReq(
        'post',
        'http://localhost:2020/student/std-reg',
        dataObj,
        function (res) {
            debugger;
            loaderRef.classList.add('disp-none');
            btnRef.removeAttribute('disabled');
            var res = JSON.parse(res);
            if (res.insertedCount == 1 && res.ok == 1) {
                msgRef.innerHTML = 'Registed successfully'
                nameRef.value = '';
                emailRef.value = '';
                phoneRef.value = '',
                    rnoRef.value = '';
            } else {

                msgRef.innerHTML = 'Not Regsitered...try again';
                msgRef.style.color = 'red';
            }
        },
        function (res) {
            debugger;
            loaderRef.classList.add('disp-none');
            btnRef.removeAttribute('disabled');
            msgRef.innerHTML = res;
            msgRef.style.color = 'red';
        }
    );





}